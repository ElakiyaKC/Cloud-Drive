#Elakiya K.C.
#1001354817
#Cloud Assignment2-Cloudant

#  Copyright 2015 IBM Corp. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from cloudant import query
from cloudant.client import Cloudant
import os
from tempfile import gettempdir
import datetime
from dateutil import parser
import hashlib
from flask import Flask, render_template,request,make_response

app = Flask(__name__)
#app.secret_key="exk4817"

#Getting the credentials for the Cloudant:
username="####"
password="####"
URL="####"

#Connecting to the cloudant
client=Cloudant(username,password,url=URL)


#Create a database
#database_4817=client.create_database('database_4817')

#checking if the database already exists
#if database_4817.exists():
    #print 'Success'


@app.route('/')
def Welcome():
    return render_template('index.html')

#Upload the file
@app.route('/upload',methods=['POST'])
def upload_file():
    if request.method=='POST':
        file = request.files['file']
        file_name = file.filename
        #file_path=os.path.abspath(file)
        #last_modified=os.path.getctime(file_name)
        #hashing fuction
        hasher = hashlib.md5()
        file_content = file.read()
        hasher.update(file_content)
        hash_value=hasher.hexdigest()
        # Connect to the server
        client.connect()

        # open an existing database
        database1 = client['database_4817']

        #takes the file name and checks the hashed content
        check_version_query=query.Query(database1,selector={'filename':file_name});
        version_number = 0
        file_exist='false'
        with query.Query.custom_result(check_version_query) as rslt:
            for doc in rslt:
                version_number=doc["version"]
                if doc["hashed_value"]==hash_value:
                    file_exist='true'
                    break;
        if file_exist=='true':
            return render_template('File_exists.html')
        else:
            if version_number == 0:
                version_number=1
            else:
                version_number=version_number + 1;
            data = {
                '_id':file_name+"_"+str(version_number),
                'hashed_value': hash_value,
                'filename': file_name,
                'version': version_number,
                'last_modified_date': str(datetime.datetime.now()),
                'actual_content': file_content
            }

            # create document in the database
            database1.create_document(data)

        client.disconnect()
        return render_template('upload.html')
        return render_template('index.html')

#download the file(file,version)
@app.route('/download',methods=['POST'])
def download():
    if request.method=='POST':
        try:
            filename=request.form['download_file']
            version=request.form['download_version']
            client.connect()
            database1 = client['database_4817']
            my_doc=database1[filename+"_"+version]
            print my_doc
            download_content=my_doc['actual_content']
            print download_content
            response = make_response(download_content)

            filepath = os.path.join(gettempdir(),filename)
           #Test
            file = open(filepath, 'w')
            print filepath
            file.write(download_content)
            file.close()
           #End Test

            response.headers["Content-Disposition"] = "attachment; filename=" + filename
            return response

        except KeyError:
            print "File does not exist"
        except Exception:
            print "Error has occured"
        finally:
            client.disconnect()
    filelists=list_files()
    return render_template('index.html')

#delete the file (filename,version)
@app.route('/delete',methods=['POST'])
def delete():
    if request.method=='POST':
        try:
            delete_files=request.form['delete_file']
            delete_version=request.form['delete_version']
            client.connect()
            database1=client['database_4817']
            my_doc=database1[delete_files+"_"+delete_version]
            my_doc.delete()
        except KeyError:
            print "File does not exists"
        except Exception:
            print "Error has occured"
        finally:
            client.disconnect()
    return render_template('Delete.html')
    return render_template('index.html')



def list_files():
    files_list = []
    client.connect()
    database1=client['database_4817']
    #filelist_query=query.Query(database1,selector={'type':'assign2files'})
    #with query.Query.cu stom_result(filelist_query) as list_result:
    for doc in database1:
        avail_file=doc['_id']+" " +doc['last_modified_date']
        files_list.append(avail_file)
    client.disconnect()
    return files_list

#sort the details according to the last modified date
@app.route('/list',methods=['POST'])
def sorted_list():
# Connect to the server
    client.connect()

    # open an existing database
    my_db = client['database_4817']

    dis_content='''<html lang="en">
    <body>
    <table border='1'>
    <tr>
    <th>File Name</th>
    <th> Last Modified Date</th>
    <th> Version Number</th>
    </tr>
    '''


    content=''''''
    list_obj=[j for j in my_db]
    list_obj.sort(key=getval)

    for data in list_obj:
        dis_content+='<tr>'
        dis_content+='<td>'+data['filename']+'</td>'
        dis_content+='<td>'+str(data['last_modified_date'])+'</td>'
        dis_content += '<td>' +str(data['version']) + '</td>'
        dis_content += '</tr>'
    dis_content+='</table></body>'
    return str(dis_content)

def getval(obj):
    return obj['filename'].lower()

#Displaying the list of the file
@app.route('/listfiles',methods=['POST'])
def list_files():
    files_list = []
    client.connect()
    my_db = client['database_4817']
    # filelist_query=query.Query(database1,selector={'type':'assign2files'})
    # with query.Query.custom_result(filelist_query) as list_result:
    for doc in my_db:
        avail_file = doc['_id'] + " " + doc['last_modified_date']
        files_list.append(avail_file)
    client.disconnect()
    return render_template('filesort.html',files_list=files_list)



port = os.getenv('PORT', '5000')
if __name__ == "__main__":
    app.run(host='0.0.0.0', port=int(port))
    app.debug='true'
    #app.run(host='127.0.0.1',port=5000)
